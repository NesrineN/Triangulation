#include "LinearEigen.h"
#include <complex>
#include <opencv2/opencv.hpp>

namespace Triangulation {

// function that performs the triangulation using the Linear Eigen Method: 
// takes 2 pixel points u and u' and P and P' the projection matrices and returns the 3D point X upon triangulation
// u=PX and u'=P'X
// function must create Matrix A which has the 4 equations and solve AX=0 using SVD decomposition
// rows of matrix A:
// uP3T-P1T
// vP3T-P2T
// u'P3'T - P1'T
// v'P3'T - P2'T

// U and U_prime are in the form of u=w(u,v,1)
cv::Point3d triangulate_Linear_Eigen(const cv::Vec3d& U, const cv::Vec3d& U_prime, const cv::Mat& P, const cv::Mat& P_prime){
    // extracting the coordinates from the u and u' vectors
    double u = U[0];
    double v = U[1];
    double u_p = U_prime[0];
    double v_p = U_prime[1];

    // creating the matrix A that is 4x4
    cv::Mat A = cv::Mat::zeros(4, 4, CV_64F);

    // filling it up
    // Row 0: uP3T-P1T
    A.row(0) = u*P.row(2) - P.row(0);
    // Row 1: vP3T-P2T
    A.row(1) = v*P.row(2) - P.row(1);
    // Row 2: u'P3'T - P1'T
    A.row(2) = u_p*P_prime.row(2) - P_prime.row(0);
    // Row 3: v'P3'T - P2'T
    A.row(3) = v_p*P_prime.row(2) - P_prime.row(1);

    // Solving Minimum of AX subject to ||X||=1 using SVD Decomposition
    cv::Mat W, U_svd, VT;
    cv::SVD::compute(A, W, U_svd, VT); // The solution X is the last row of VT
    cv::Mat solution = VT.row(VT.rows - 1); // solution is a 1x4 matrix

    double w_hom = solution.at<double>(3);

    if(std::abs(w_hom) > 1e-9){
        double X= solution.at<double>(0) / w_hom;
        double Y= solution.at<double>(1) / w_hom;
        double Z= solution.at<double>(2) / w_hom;

        if(Z<0){return cv::Point3d(0, 0, 0); // point is behind the camera
        }

        return cv::Point3d(X, Y, Z);
    }
    else{
        return cv::Point3d(0, 0, 0); // point at inifinity
    }
}

}


